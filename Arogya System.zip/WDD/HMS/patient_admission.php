
<html>
<head>
	<title></title>
<head>
<body>
		<?php 
				$servername = "localhost";
				$username = "username";
				$password = "password";


				//create connection
					$con = new mysqli('localhost', 'root', '', 'arogya');
				// chech the connection
					if ($con ->connect_error)
					{
						die("connection failed:".$con ->connect_error);
					}

				$sql = "insert into patient (ID,Full Name, Age,Gender,DOB,City,Admitting Date,Telephone Number, Marital Status, Email Address	,Responsible Party Name	,Responsible Party Telephone Number)
                VALUES('$_POST[ID]','$_POST[fullName]','$_POST[age]','$_POST[Gender]','$_POST[birthDate]','$_POST[city]','$_POST[admitDate]','$_POST[telephone]','$_POST[maritalStatus]','$_POST[email]','$_POST[responsibilityName]','$_POST[responsibilityTelephone]')";
					if ($con->query($sql)=== TRUE)
					{
						print(".............Record inserted");
                    }
					else 
					{
						print("ERROR: ". $sql."<br>" . $con -> error);
					}



		 ?>

                </body>
</html>