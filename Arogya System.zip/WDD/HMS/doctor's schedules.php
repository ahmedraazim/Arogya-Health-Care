<form action="schedule.php" method="post">
  <label for="Monday">Monday:</label>
  <input type="text" id="Monday" name="Monday" value="<?php echo $schedule['Monday']; ?>">

  <label for="Tuesday">Tuesday:</label>
  <input type="text" id="Tuesday" name="Tuesday" value="<?php echo $schedule['Tuesday']; ?>">

  <label for="Wednesday">Wednesday:</label>
  <input type="text" id="Wednesday" name="Wednesday" value="<?php echo $schedule['Wednesday']; ?>">

  <label for="Thursday">Thursday:</label>
  <input type="text" id="Thursday" name="Thursday" value="<?php echo $schedule['Thursday']; ?>">

  <label for="Friday">Friday:</label>
  <input type="text" id="Friday" name="Friday" value="<?php echo $schedule['Friday']; ?>">

  <input type="submit" value="Update Schedule">
</form>