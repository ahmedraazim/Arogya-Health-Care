const updateBtns = document.querySelectorAll('#update-btn');

for (let i = 0; i < updateBtns.length; i++) {
updateBtns[i].addEventListener('click', function() {
alert('Updating schedule for ' + updateBtns[i].parentNode.parentNode.firstChild.textContent + '...');
});
}