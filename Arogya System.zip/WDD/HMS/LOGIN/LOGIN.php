<?php
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Connect to the database
  $conn = new mysqli('localhost', 'username', 'password', 'database');

  // Check if the user has entered the correct login information
  $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
  $result = $conn->query($sql);
  if ($result->num_rows > 0) {
    // Login successful, redirect to the homepage
    header("Location: homepage.php");
    exit();
  } else {
    // Login failed, display an error message
    echo "Invalid username or password";
  }
?>
